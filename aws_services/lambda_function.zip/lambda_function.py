import boto3
import json
from datetime import datetime

DYNAMODB_TABLE_NAME = 'Devices'
AWS_REGION = 'us-east-1'

dynamodb = boto3.resource('dynamodb', region_name=AWS_REGION)
table = dynamodb.Table(DYNAMODB_TABLE_NAME)

def lambda_handler(event, context):
    current_time = datetime.utcnow()
    
    try:
        response = table.scan()
        devices = response.get('Items', [])

        for device in devices:
            device_id = device['device_id']
            last_data_received = device.get('last_data_received')
            battery_level = device.get('battery_level')

            if last_data_received:
                last_data_time = datetime.fromisoformat(last_data_received)
                time_diff = (current_time - last_data_time).total_seconds() / 60  # Convert to minutes
                
                if time_diff > 60 and device['status'] != 'Idle':
                    table.update_item(
                        Key={'device_id': device_id},
                        UpdateExpression='SET status = :status',
                        ExpressionAttributeValues={':status': 'Idle'}
                    )

            if battery_level is not None and battery_level < 10:
                table.update_item(
                    Key={'device_id': device_id},
                    UpdateExpression='SET status = :status',
                    ExpressionAttributeValues={':status': 'Error (Low Battery)'}
                )

        return {'statusCode': 200, 'body': json.dumps('Lambda function executed successfully')}

    except Exception as e:
        return {'statusCode': 500, 'body': json.dumps(f'Error: {str(e)}')}
